package kmeans;
import kmeans.form.GUIKnn;

public class main {
    public static void main(String[] args) {
        GUIKnn inter = new GUIKnn();
        inter.vista();

    }
}
